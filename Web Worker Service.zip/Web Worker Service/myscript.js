//var msg = "Task initiated";
//msg += "Task completed";

var data;
self.onmessage = function (e) {
    //goto database through some service and get the details of the person
    data = { "name": e.data, "city": "Bangalore", "state": "Karnataka" };    
    setTimeout("doTask()",5000)
}

function doTask() {    
    postMessage(data);
}


