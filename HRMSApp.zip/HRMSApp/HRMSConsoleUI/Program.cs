﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSEntitiesLib; //for Entities Layer
using HRMLBusinessLib; //for Business Layer
namespace HRMSConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.WriteLine("1.Add Employee");
                Console.WriteLine("2.Delete Emp By Id");
                Console.WriteLine("3.Update Emp By Id");
                Console.WriteLine("4.Display All Emps");
                Console.WriteLine("5.Search Emp By Id");
                Console.WriteLine("0.Exit");
                Console.Write("Enter choice:");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        //DELETE EMP BY ID
                        DeleteEmpById();
                        break;
                    case 3:
                        //UPDATE EMP BY ID
                        UpdateEmpById();
                        //UpdateEmpSalUsingSP();
                        break;
                    case 4:
                        DisplayAllEmps();
                        break;
                    case 5:
                        //SEARCH BY ID
                        GetEmpById();
                        //GetEmpSalaryUsingSP();
                        break;
                    case 0:
                        Console.WriteLine("Exiting....");
                        break;
                    default:
                        Console.WriteLine("invalid choice:");
                        break;
                }
            } while (choice != 0);       

        }

        static void GetEmpById()
        {
            try
            {
                int ecode;
                Employee emp = null;

                Console.Write("Enter ecode for search:");
                ecode = int.Parse(Console.ReadLine());
                //Search emp using business layer
                BusinessLayer bll = new BusinessLayer();
                emp = bll.SelectEmpById(ecode);

                Console.WriteLine(emp.Ecode + "\t" + emp.Ename + "\t" + emp.Salary + "\t" + emp.Deptid);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void UpdateEmpById()
        {
            try
            {
                Employee emp = new Employee();

                Console.Write("Enter ecode for update:");
                emp.Ecode = int.Parse(Console.ReadLine());
                Console.Write("Enter ename:");
                emp.Ename = Console.ReadLine();
                Console.Write("Enter salary:");
                emp.Salary = int.Parse(Console.ReadLine());
                Console.Write("Enter deptid:");
                emp.Deptid = int.Parse(Console.ReadLine());

                //update using Business layer
                BusinessLayer bll = new BusinessLayer();
                bll.UpdateEmpById(emp);
                Console.WriteLine("Record updated successfully");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        static void DeleteEmpById()
        {
            try
            {
                int ecode;
                Console.Write("Enter ecode:");
                ecode = int.Parse(Console.ReadLine());

                //Delete using Business Layer
                BusinessLayer bll = new BusinessLayer();
                bll.DeleteEmpById(ecode);
                Console.WriteLine("Record deleted successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void AddEmployee()
        {
            //Add Employee
            Employee emp = new Employee();

            Console.Write("Enter ecode:");
            emp.Ecode = int.Parse(Console.ReadLine());
            Console.Write("Enter ename:");
            emp.Ename = Console.ReadLine();
            Console.Write("Enter salary:");
            emp.Salary = int.Parse(Console.ReadLine());
            Console.Write("Enter deptid:");
            emp.Deptid = int.Parse(Console.ReadLine());

            //insert using Business layer
            BusinessLayer bll = new BusinessLayer();
            bll.AddEmployee(emp);
            Console.WriteLine("Record inserted successfully");
        }
        static void DisplayAllEmps()
        {
            BusinessLayer bll = new BusinessLayer();
            List<Employee> lstEmps = bll.GetAllEmps();

            foreach (Employee emp in lstEmps)
            {
                Console.WriteLine(emp.Ecode + "\t" + emp.Ename + "\t" + emp.Salary + "\t" + emp.Deptid);
            }
        }

        static void UpdateEmpSalUsingSP()
        {
            try
            {
                Console.Write("Enter ecode for update:");
                int ecode = int.Parse(Console.ReadLine());
                
                Console.Write("Enter salary:");
                int salary = int.Parse(Console.ReadLine());
                

                //update using Business layer (SP)
                BusinessLayer bll = new BusinessLayer();
                bll.UpdateSalaryUsingSP(ecode,salary);
                Console.WriteLine("Record updated successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        static void GetEmpSalaryUsingSP()
        {
            try
            {
                int ecode, salary;
                Console.Write("Enter ecode to display salary:");
                ecode = int.Parse(Console.ReadLine());

                //Get the salary using Business layer
                BusinessLayer bll = new BusinessLayer();
                salary = bll.GetEmpSalUsingSP(ecode);

                Console.WriteLine("Salary:" + salary);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
