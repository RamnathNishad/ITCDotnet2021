﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSDataAccessLib; //for DAL
using HRMSEntitiesLib; //for Entities

namespace HRMLBusinessLib
{
    public class BusinessLayer
    {
        public List<Employee> GetAllEmps()
        {
            List<Employee> lstEmps = new List<Employee>();

            //get the records from Data Access Layer
            //AdoConnected dal = new AdoConnected();
            AdoDisconnected dal = new AdoDisconnected();
            lstEmps = dal.SelectAllEmps();

            return lstEmps;
        }

        public void AddEmployee(Employee emp)
        {
            //add record using DAL layer
            //AdoConnected dal = new AdoConnected();
            AdoDisconnected dal = new AdoDisconnected();
            dal.InsertEmployee(emp);
        }

        public void DeleteEmpById(int ecode)
        {
            //delete record using DAL layer
            //AdoConnected dal = new AdoConnected();
            AdoDisconnected dal = new AdoDisconnected();
            dal.DeleteEmpById(ecode);

        }

        public void UpdateEmpById(Employee emp)
        {
            //update using DAL layer
            //AdoConnected dal = new AdoConnected();
            AdoDisconnected dal = new AdoDisconnected();
            dal.UpdateEmpById(emp);
        }

        public Employee SelectEmpById(int ecode)
        {
            //get the record using DAL layer
            //AdoConnected dal = new AdoConnected();
            AdoDisconnected dal = new AdoDisconnected();
            Employee emp = dal.SelectEmpById(ecode);

            return emp;
        }

        public void UpdateSalaryUsingSP(int ecode,int salary)
        {
            //update using DAL layer
            AdoConnected dal = new AdoConnected();
            dal.UpdateSalaryUsingSP(ecode, salary);
        }

        public int GetEmpSalUsingSP(int ecode)
        {
            int salary = 0;
            //get the salary of employee using DAL layer
            AdoConnected dal = new AdoConnected();
            salary = dal.GetEmpSalUsingSP(ecode);

            return salary;
        }

        public void DoTransaction()
        {
            AdoConnected dal = new AdoConnected();
            dal.DoTransaction();
        }
    }
}
