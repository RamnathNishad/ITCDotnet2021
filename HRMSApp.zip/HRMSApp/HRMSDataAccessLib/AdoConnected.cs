﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSEntitiesLib; //for Entities Layer
using System.Data.SqlClient; //for SQL Server Provider
using System.Data;

namespace HRMSDataAccessLib
{
    public class AdoConnected : IDataAccess
    {
        SqlConnection con;
        SqlCommand cmd;

        public AdoConnected()
        {
            //create and configure the connection obejct
            con = new SqlConnection();
            con.ConnectionString = @"Data Source=ASUSRAM\SQLEXPRESS;Initial Catalog=HRMSDB;Integrated Security=True";
        }

        public void DeleteEmpById(int ecode)
        {
            try
            {
                //configure command for DELETE BY ID
                cmd = new SqlCommand();
                cmd.CommandText = "delete from tbl_employee where ecode=@ec";
                cmd.CommandType = CommandType.Text;

                //supply parameter value
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ec", ecode);

                //attach connection
                cmd.Connection = con;

                //open connection
                con.Open();
                //execute the command
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new Exception("Ecode does not exist, could not perform delete");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public void InsertEmployee(Employee emp)
        {
            //configure SqlCommand for INSERT
            cmd = new SqlCommand();
            cmd.CommandText = "insert into tbl_employee values(@ec,@en,@sal,@did)";
            cmd.CommandType = CommandType.Text;

            //supply parameters values
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ec", emp.Ecode);
            cmd.Parameters.AddWithValue("@en", emp.Ename);
            cmd.Parameters.AddWithValue("@sal", emp.Salary);
            cmd.Parameters.AddWithValue("@did", emp.Deptid);

            //attach the connection
            cmd.Connection = con;
            //open connection
            con.Open();
            //execute the command
            cmd.ExecuteNonQuery();  
            //close the connection
            con.Close();
        }

        public List<Employee> SelectAllEmps()
        {
            List<Employee> lstEmps = new List<Employee>();

            //configure SQL Command for SELECT ALL
            cmd = new SqlCommand();
            cmd.CommandText = "select ecode,ename,salary,deptid from tbl_employee";
            cmd.CommandType = CommandType.Text;

            //attach connection with the command
            cmd.Connection = con;

            //open the connection
            con.Open();

            //execute the command
            SqlDataReader sdr = cmd.ExecuteReader();

            //traverse the records of the DataReader one-by-one
            while(sdr.Read())
            {
                //Take the values of the current record columns
                Employee emp = new Employee
                {
                   Ecode= (int)sdr[0],
                   Ename =sdr[1].ToString(),
                   Salary=(int)sdr[2],
                   Deptid=(int)sdr[3]
                };
                //add the record to the collection
                lstEmps.Add(emp);
            }

            sdr.Close();
            con.Close();

            return lstEmps;
        }

        public Employee SelectEmpById(int ecode)
        {
            Employee emp = null;
            try
            {
                //configure sql command for SELECT BY ID
                cmd = new SqlCommand();
                cmd.CommandText = "select ecode,ename,salary,deptid from tbl_employee where ecode=@ec";
                cmd.CommandType = CommandType.Text;

                //supply paramter value
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ec", ecode);

                //attach connection
                cmd.Connection = con;
                //open connection
                con.Open();
                //execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    emp = new Employee
                    {
                        Ecode=(int)sdr[0],
                        Ename=sdr[1].ToString(),
                        Salary=(int)sdr[2],    
                        Deptid=(int)sdr[3]
                    };
                    sdr.Close();
                }
                else
                {
                    throw new Exception("ecode does not exist");
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return emp;
        }

        public void UpdateEmpById(Employee emp)
        {
            try
            {
                //configure command for UPDATE BY ID
                cmd = new SqlCommand();
                cmd.CommandText = "update tbl_employee set ename=@en,salary=@sal,deptid=@did where ecode=@ec";
                cmd.CommandType = CommandType.Text;

                //supply the parameters values
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ec", emp.Ecode);
                cmd.Parameters.AddWithValue("@en", emp.Ename);
                cmd.Parameters.AddWithValue("@sal", emp.Salary);
                cmd.Parameters.AddWithValue("@did", emp.Deptid);

                //attach connection
                cmd.Connection = con;

                //open connection
                con.Open();
                //execute the command
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new Exception("Ecode does not exist, could not perform the updation");
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public void UpdateSalaryUsingSP(int ecode,int salary)
        {
            try
            {
                //configure Sql Command for calling Stored Procedure
                cmd = new SqlCommand();
                cmd.CommandText = "sp_UpdateEmpSal";
                cmd.CommandType = CommandType.StoredProcedure; //mandatory

                //supply parameters for the stored procedure
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ec", ecode);
                cmd.Parameters.AddWithValue("@sal", salary);

                //attach connection
                cmd.Connection = con;
                //open connection
                con.Open();
                //execute the command(SP)
                cmd.ExecuteNonQuery();
                //close the connection
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public int GetEmpSalUsingSP(int ecode)
        {
            int salary = 0;
            try
            {
                //configure the sql command for Stored Procedure
                cmd = new SqlCommand();
                cmd.CommandText = "sp_getempsal";
                cmd.CommandType = CommandType.StoredProcedure;

                //supply parameters values
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ec", ecode);
                cmd.Parameters.AddWithValue("@sal", salary);

                //specify the Parameters Direction
                cmd.Parameters[1].Direction = ParameterDirection.Output;

                //attach connection
                cmd.Connection = con;
                //open connection 
                con.Open();
                //execute the command(SP)
                cmd.ExecuteNonQuery();

                //access the parameter value from SP
                salary = (int)cmd.Parameters[1].Value;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //close
                con.Close();
            }

            return salary;
        }

        public void DoTransaction()
        {
            SqlTransaction T = null;
            try
            {
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = "update tbl_employee set salary = salary + 1000 where ecode = 101";
                cmd1.Connection = con;

                SqlCommand cmd2 = new SqlCommand();
                cmd2.CommandText = "delete from tbl_employee where ecode=105";
                cmd2.Connection = con;

                con.Open();
                //initiate a Transaction
                T = con.BeginTransaction();
                //attach the logically related command with the transaction
                cmd1.Transaction = T;
                cmd2.Transaction = T;

                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                //commit
                T.Commit();
            }
            catch (SqlException ex)
            {
                //rollback 
                T.Rollback();
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}



//Transactions:-
//set of statements which should execute logically as a one unit and as a whole(either all or none). 
//If any statement fails, everything should be rolled back to previous consistent state of database
