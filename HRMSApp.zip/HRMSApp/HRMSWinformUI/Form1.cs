﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using HRMLBusinessLib; //for Business layer
using HRMSEntitiesLib; //for entities layer


namespace HRMSWinformUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    Ecode = int.Parse(txtEcode.Text),
                    Ename = txtEname.Text,
                    Salary = int.Parse(txtSalary.Text),
                    Deptid = int.Parse(txtDeptid.Text)
                };

                BusinessLayer bll = new BusinessLayer();
                bll.AddEmployee(emp);
                MessageBox.Show("Record inserted");

                //Display records DataGridView
                List<Employee> lstEmps = bll.GetAllEmps();
                dgvEmps.DataSource = lstEmps;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int ecode = int.Parse(txtEcode.Text);
                BusinessLayer bll = new BusinessLayer();
                bll.DeleteEmpById(ecode);
                MessageBox.Show("Record deleted");

                //Display records in DataGridView
                List<Employee> lstEmps = bll.GetAllEmps();
                dgvEmps.DataSource = lstEmps;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    Ecode = int.Parse(txtEcode.Text),
                    Ename = txtEname.Text,
                    Salary = int.Parse(txtSalary.Text),
                    Deptid = int.Parse(txtDeptid.Text)
                };
                BusinessLayer bll = new BusinessLayer();
                bll.UpdateEmpById(emp);
                MessageBox.Show("Record updated");

                //Display records in DataGridView
                List<Employee> lstEmps = bll.GetAllEmps();
                dgvEmps.DataSource = lstEmps;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFindEmp_Click(object sender, EventArgs e)
        {
            try
            {
                int ecode = int.Parse(txtEcode.Text);
                BusinessLayer bll = new BusinessLayer();
                Employee emp = bll.SelectEmpById(ecode);
                txtEname.Text = emp.Ename;
                txtSalary.Text = emp.Salary.ToString();
                txtDeptid.Text = emp.Deptid.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display records DataGridView
            BusinessLayer bll = new BusinessLayer();
            List<Employee> lstEmps = bll.GetAllEmps();
            dgvEmps.DataSource = lstEmps;
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            try
            {
                BusinessLayer bll = new BusinessLayer();
                bll.DoTransaction();
                MessageBox.Show("Transaction success");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
